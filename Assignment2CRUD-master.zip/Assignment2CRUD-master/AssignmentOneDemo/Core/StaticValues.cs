﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace Core
{
    public static class StaticValues
    {
        public static Guid PassStatus = new Guid("54dc704f-f8ca-4d67-a6a1-ee33c544b8d9");
        public static Guid FailStatus = new Guid("7a510a85-86a7-4344-b6f3-21e34a55c63b");
    }
}
